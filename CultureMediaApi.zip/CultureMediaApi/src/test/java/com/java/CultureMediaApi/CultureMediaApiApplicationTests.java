package com.java.CultureMediaApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CultureMediaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

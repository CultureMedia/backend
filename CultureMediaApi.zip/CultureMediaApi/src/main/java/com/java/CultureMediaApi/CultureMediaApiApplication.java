package com.java.CultureMediaApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CultureMediaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CultureMediaApiApplication.class, args);
	}

}
